**AD-FMCJESDADC1-EBZ** Bare Metal Quick Start Guide: [https://wiki.analog.com/resources/eval/user-guides/ad-fmcjesdadc1-ebz/software/baremetal] (https://wiki.analog.com/resources/eval/user-guides/ad-fmcjesdadc1-ebz/software/baremetal)

The following drivers are required for building the **AD-FMCJESDADC1-EBZ** no-OS project:
 - AD-FMCJESDADC1-EBZ Main, AD9250, AD9517 Drivers	-	[./] (./)
 - Xilinx Platform Drivers							-	[../common_drivers/xilinx_platform_drivers] (../common_drivers/xilinx_platform_drivers)
 - ADC Core Driver									-	[../common_drivers/adc_core] (../common_drivers/adc_core)
 - JESD204B GT Driver								-	[../common_drivers/jesd204b_gt] (../common_drivers/jesd204b_gt)
 - JESD204B V51 Driver								-	[../common_drivers/jesd204b_v51] (../common_drivers/jesd204b_v51)
