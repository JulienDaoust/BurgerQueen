This project requires the ADV7511 Transmitter Library:
 - https://github.com/analogdevicesinc/no-OS/tree/master/adv7511/library/microblaze