The AD9467-FMC-EBZ reference design requires the following drivers:
 - AD9467 -> https://github.com/analogdevicesinc/no-OS/tree/master/drivers/AD9467
 - AD9517 -> https://github.com/analogdevicesinc/no-OS/tree/master/drivers/AD9517