**AD9265-FMC-125EBZ**

The following drivers are required for building the **AD9265-FMC-125EBZ** no-OS project:
 - AD9265-FMC-125EBZ Main Driver	-	[./] (./)
 - Xilinx Platform Drivers		-	[../common_drivers/xilinx_platform_drivers] (../common_drivers/xilinx_platform_drivers)
 - AD9265 Driver				-	[../drivers/ad9265] (../drivers/ad9265)
 - ADC Core Driver				-	[../common_drivers/adc_core] (../common_drivers/adc_core)
